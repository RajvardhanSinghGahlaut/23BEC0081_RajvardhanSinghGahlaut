package com.hostel.management.service;

import com.hostel.management.dto.WardenDTO;
import com.hostel.management.exception.ResourceNotFoundException;
import com.hostel.management.model.Warden;
import com.hostel.management.repository.HostelRepository;
import com.hostel.management.repository.WardenRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class WardenService {

    private final WardenRepository wardenRepository;
    private final HostelRepository hostelRepository;

    public WardenDTO createWarden(WardenDTO dto) {
        // Validate hostel existence
        if (!hostelRepository.existsById(dto.getHostelId())) {
            throw new ResourceNotFoundException("Hostel not found with id: " + dto.getHostelId());
        }

        Warden warden = Warden.builder()
                .name(dto.getName())
                .email(dto.getEmail())
                .phoneNumber(dto.getPhoneNumber())
                .hostelId(dto.getHostelId())
                .build();
        warden = wardenRepository.save(warden);
        return convertToDTO(warden);
    }

    public WardenDTO getWardenById(String wardenId) {
        Warden warden = wardenRepository.findById(wardenId)
                .orElseThrow(() -> new ResourceNotFoundException("Warden not found with id: " + wardenId));
        return convertToDTO(warden);
    }

    public List<WardenDTO> getAllWardens() {
        return wardenRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public WardenDTO updateWarden(String wardenId, WardenDTO dto) {
        Warden warden = wardenRepository.findById(wardenId)
                .orElseThrow(() -> new ResourceNotFoundException("Warden not found with id: " + wardenId));

        if (!hostelRepository.existsById(dto.getHostelId())) {
            throw new ResourceNotFoundException("Hostel not found with id: " + dto.getHostelId());
        }

        warden.setName(dto.getName());
        warden.setEmail(dto.getEmail());
        warden.setPhoneNumber(dto.getPhoneNumber());
        warden.setHostelId(dto.getHostelId());

        warden = wardenRepository.save(warden);
        return convertToDTO(warden);
    }

    public void deleteWarden(String wardenId) {
        Warden warden = wardenRepository.findById(wardenId)
                .orElseThrow(() -> new ResourceNotFoundException("Warden not found with id: " + wardenId));
        wardenRepository.delete(warden);
    }

    private WardenDTO convertToDTO(Warden warden) {
        return WardenDTO.builder()
                .wardenId(warden.getWardenId())
                .name(warden.getName())
                .email(warden.getEmail())
                .phoneNumber(warden.getPhoneNumber())
                .hostelId(warden.getHostelId())
                .build();
    }
}
