package com.hostel.management.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "students")
public class Student {

    @Id
    private String studentId;
    
    @Indexed(unique = true)
    private String registrationNumber;
    
    private String name;
    
    private String email;
    
    private String phoneNumber;
    
    private String gender;
    
    private String department;
    
    private String roomId;        // Reference to Room
    
    private String hostelId;      // Reference to Hostel
    
    private String hostelCardId;  // Reference to HostelCard
}
