package com.hostel.management.controller;

import com.hostel.management.dto.VisitorDTO;
import com.hostel.management.service.VisitorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/visitors")
@RequiredArgsConstructor
@Tag(name = "Visitor Management", description = "Endpoints for logging hostel visitor entries and exits")
public class VisitorController {

    private final VisitorService visitorService;

    @PostMapping("/entry")
    @Operation(summary = "Record visitor entry", description = "Logs entry of a visitor visiting a student. Auto-populates entry timestamp.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Visitor entry logged successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid payload"),
            @ApiResponse(responseCode = "404", description = "Student not found")
    })
    public ResponseEntity<VisitorDTO> createVisitorEntry(@Valid @RequestBody VisitorDTO dto) {
        return new ResponseEntity<>(visitorService.createVisitorEntry(dto), HttpStatus.CREATED);
    }

    @PatchMapping("/{id}/exit")
    @Operation(summary = "Record visitor exit", description = "Logs exit of a visitor. Sets exit timestamp dynamically.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Visitor exit logged successfully"),
            @ApiResponse(responseCode = "400", description = "Visitor has already exited"),
            @ApiResponse(responseCode = "404", description = "Visitor record not found")
    })
    public ResponseEntity<VisitorDTO> updateVisitorExit(
            @Parameter(description = "ID of the visitor record to update exit time", required = true)
            @PathVariable String id) {
        return ResponseEntity.ok(visitorService.updateVisitorExit(id));
    }

    @GetMapping("/history")
    @Operation(summary = "Get visitor history", description = "Retrieves visitor logs. Can be filtered by student ID.")
    public ResponseEntity<List<VisitorDTO>> getVisitorHistory(
            @Parameter(description = "ID of the student to filter visitor history for")
            @RequestParam(required = false) String studentId) {
        return ResponseEntity.ok(visitorService.getVisitorHistory(studentId));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete visitor record", description = "Deletes a visitor entry from the history.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Visitor record deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Visitor record not found")
    })
    public ResponseEntity<Void> deleteVisitor(
            @Parameter(description = "ID of the visitor record to delete", required = true)
            @PathVariable String id) {
        visitorService.deleteVisitor(id);
        return ResponseEntity.noContent().build();
    }
}
