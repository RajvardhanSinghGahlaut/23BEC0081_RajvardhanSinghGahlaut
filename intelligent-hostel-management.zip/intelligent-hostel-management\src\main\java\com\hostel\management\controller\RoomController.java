package com.hostel.management.controller;

import com.hostel.management.dto.RoomDTO;
import com.hostel.management.service.RoomService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/rooms")
@RequiredArgsConstructor
@Tag(name = "Room Management", description = "Endpoints for managing Hostel Rooms")
public class RoomController {

    private final RoomService roomService;

    @PostMapping
    @Operation(summary = "Create a new room", description = "Creates a room inside a hostel. Updates hostel capacity details.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Room created successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload / Room already exists"),
            @ApiResponse(responseCode = "404", description = "Hostel or Warden not found")
    })
    public ResponseEntity<RoomDTO> createRoom(@Valid @RequestBody RoomDTO dto) {
        return new ResponseEntity<>(roomService.createRoom(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get room by ID", description = "Fetches details of a specific room.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Room found"),
            @ApiResponse(responseCode = "404", description = "Room not found")
    })
    public ResponseEntity<RoomDTO> getRoomById(
            @Parameter(description = "ID of the room to retrieve", required = true)
            @PathVariable String id) {
        return ResponseEntity.ok(roomService.getRoomById(id));
    }

    @GetMapping
    @Operation(summary = "Get all rooms", description = "Retrieves all rooms. Optional room number search is supported.")
    public ResponseEntity<List<RoomDTO>> getAllRooms(
            @Parameter(description = "Search filter for room number")
            @RequestParam(required = false) String roomNumber) {
        if (roomNumber != null && !roomNumber.trim().isEmpty()) {
            return ResponseEntity.ok(roomService.searchRoomsByNumber(roomNumber));
        }
        return ResponseEntity.ok(roomService.getAllRooms());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a room", description = "Updates details of an existing room.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Room updated successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request or capacity validation error"),
            @ApiResponse(responseCode = "404", description = "Room, Hostel, or Warden not found")
    })
    public ResponseEntity<RoomDTO> updateRoom(
            @Parameter(description = "ID of the room to update", required = true)
            @PathVariable String id,
            @Valid @RequestBody RoomDTO dto) {
        return ResponseEntity.ok(roomService.updateRoom(id, dto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a room", description = "Deletes a room. Room must not contain any residents to be deleted.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Room deleted successfully"),
            @ApiResponse(responseCode = "400", description = "Room has active residents"),
            @ApiResponse(responseCode = "404", description = "Room not found")
    })
    public ResponseEntity<Void> deleteRoom(
            @Parameter(description = "ID of the room to delete", required = true)
            @PathVariable String id) {
        roomService.deleteRoom(id);
        return ResponseEntity.noContent().build();
    }
}
