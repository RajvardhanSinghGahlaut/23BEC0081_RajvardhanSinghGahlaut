package com.hostel.management.dto;

import com.hostel.management.model.ComplaintStatus;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ComplaintDTO {
    private String complaintId;

    @NotBlank(message = "Student ID is mandatory")
    private String studentId;

    @NotBlank(message = "Title is mandatory")
    private String title;

    @NotBlank(message = "Description is mandatory")
    private String description;

    private LocalDateTime complaintDate;
    
    private ComplaintStatus status;
}
