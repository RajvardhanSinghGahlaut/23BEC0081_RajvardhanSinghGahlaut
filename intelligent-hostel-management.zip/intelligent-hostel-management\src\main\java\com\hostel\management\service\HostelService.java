package com.hostel.management.service;

import com.hostel.management.dto.HostelDTO;
import com.hostel.management.dto.HostelStatsResponse;
import com.hostel.management.exception.ResourceNotFoundException;
import com.hostel.management.model.Hostel;
import com.hostel.management.model.Room;
import com.hostel.management.repository.HostelRepository;
import com.hostel.management.repository.RoomRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class HostelService {

    private final HostelRepository hostelRepository;
    private final RoomRepository roomRepository;

    public HostelDTO createHostel(HostelDTO dto) {
        Hostel hostel = Hostel.builder()
                .hostelName(dto.getHostelName())
                .hostelType(dto.getHostelType())
                .totalRooms(dto.getTotalRooms())
                .occupiedRooms(0)
                .vacancyCount(0)
                .build();
        hostel = hostelRepository.save(hostel);
        return convertToDTO(hostel);
    }

    public HostelDTO getHostelById(String hostelId) {
        Hostel hostel = hostelRepository.findById(hostelId)
                .orElseThrow(() -> new ResourceNotFoundException("Hostel not found with id: " + hostelId));
        return convertToDTO(hostel);
    }

    public List<HostelDTO> getAllHostels() {
        return hostelRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<HostelDTO> searchHostelsByName(String name) {
        return hostelRepository.findByHostelNameContainingIgnoreCase(name).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public HostelDTO updateHostel(String hostelId, HostelDTO dto) {
        Hostel hostel = hostelRepository.findById(hostelId)
                .orElseThrow(() -> new ResourceNotFoundException("Hostel not found with id: " + hostelId));
        
        hostel.setHostelName(dto.getHostelName());
        hostel.setHostelType(dto.getHostelType());
        hostel.setTotalRooms(dto.getTotalRooms());
        
        hostel = hostelRepository.save(hostel);
        updateHostelStats(hostelId);
        return getHostelById(hostelId);
    }

    public void deleteHostel(String hostelId) {
        Hostel hostel = hostelRepository.findById(hostelId)
                .orElseThrow(() -> new ResourceNotFoundException("Hostel not found with id: " + hostelId));
        
        List<Room> rooms = roomRepository.findByHostelId(hostelId);
        if (!rooms.isEmpty()) {
            throw new IllegalStateException("Cannot delete hostel. It still has rooms associated with it.");
        }
        hostelRepository.delete(hostel);
    }

    public void updateHostelStats(String hostelId) {
        Hostel hostel = hostelRepository.findById(hostelId).orElse(null);
        if (hostel == null) return;

        List<Room> rooms = roomRepository.findByHostelId(hostelId);
        int total = rooms.size();
        
        int occupied = (int) rooms.stream()
                .filter(room -> room.getCurrentOccupancy() > 0)
                .count();

        int vacantRooms = (int) rooms.stream()
                .filter(room -> room.getCurrentOccupancy() < room.getCapacity())
                .count();

        hostel.setTotalRooms(total);
        hostel.setOccupiedRooms(occupied);
        hostel.setVacancyCount(vacantRooms);
        hostelRepository.save(hostel);
    }

    public HostelStatsResponse getHostelStats(String hostelId) {
        Hostel hostel = hostelRepository.findById(hostelId)
                .orElseThrow(() -> new ResourceNotFoundException("Hostel not found with id: " + hostelId));

        List<Room> rooms = roomRepository.findByHostelId(hostelId);
        
        int totalRooms = rooms.size();
        int occupiedRooms = (int) rooms.stream()
                .filter(room -> room.getCurrentOccupancy() > 0)
                .count();
        int vacantRooms = (int) rooms.stream()
                .filter(room -> room.getCurrentOccupancy() < room.getCapacity())
                .count();

        int totalCapacity = rooms.stream().mapToInt(Room::getCapacity).sum();
        int currentOccupancy = rooms.stream().mapToInt(Room::getCurrentOccupancy).sum();
        int vacantBeds = totalCapacity - currentOccupancy;
        
        double occupancyPercentage = totalCapacity > 0 
                ? ((double) currentOccupancy * 100.0) / totalCapacity 
                : 0.0;

        return HostelStatsResponse.builder()
                .hostelId(hostel.getHostelId())
                .hostelName(hostel.getHostelName())
                .totalRooms(totalRooms)
                .occupiedRooms(occupiedRooms)
                .vacantRooms(vacantRooms)
                .totalCapacity(totalCapacity)
                .currentOccupancy(currentOccupancy)
                .vacantBeds(vacantBeds)
                .occupancyPercentage(Math.round(occupancyPercentage * 100.0) / 100.0)
                .build();
    }

    private HostelDTO convertToDTO(Hostel hostel) {
        return HostelDTO.builder()
                .hostelId(hostel.getHostelId())
                .hostelName(hostel.getHostelName())
                .hostelType(hostel.getHostelType())
                .totalRooms(hostel.getTotalRooms())
                .occupiedRooms(hostel.getOccupiedRooms())
                .vacancyCount(hostel.getVacancyCount())
                .build();
    }
}
