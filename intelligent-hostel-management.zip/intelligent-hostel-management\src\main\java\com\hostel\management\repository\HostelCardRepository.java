package com.hostel.management.repository;

import com.hostel.management.model.HostelCard;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface HostelCardRepository extends MongoRepository<HostelCard, String> {
    Optional<HostelCard> findByStudentId(String studentId);
    Optional<HostelCard> findByCardNumber(String cardNumber);
    boolean existsByCardNumber(String cardNumber);
    void deleteByStudentId(String studentId);
}
