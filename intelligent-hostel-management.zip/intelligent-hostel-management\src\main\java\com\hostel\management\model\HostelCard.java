package com.hostel.management.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "hostel_cards")
public class HostelCard {

    @Id
    private String cardId;
    
    @Indexed(unique = true)
    private String cardNumber;
    
    private LocalDate issueDate;
    
    private String studentId; // Reference to Student
}
