package com.hostel.management.controller;

import com.hostel.management.dto.HostelDTO;
import com.hostel.management.dto.HostelStatsResponse;
import com.hostel.management.service.HostelService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/hostels")
@RequiredArgsConstructor
@Tag(name = "Hostel Management", description = "Endpoints for managing Hostels and viewing overall occupancy statistics")
public class HostelController {

    private final HostelService hostelService;

    @PostMapping
    @Operation(summary = "Create a new hostel", description = "Creates a new hostel in the system.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "210", description = "Hostel created successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload")
    })
    public ResponseEntity<HostelDTO> createHostel(@Valid @RequestBody HostelDTO dto) {
        return new ResponseEntity<>(hostelService.createHostel(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get hostel by ID", description = "Fetches details of a specific hostel.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Hostel found"),
            @ApiResponse(responseCode = "404", description = "Hostel not found")
    })
    public ResponseEntity<HostelDTO> getHostelById(
            @Parameter(description = "ID of the hostel to be retrieved", required = true)
            @PathVariable String id) {
        return ResponseEntity.ok(hostelService.getHostelById(id));
    }

    @GetMapping
    @Operation(summary = "Get all hostels", description = "Retrieves all hostels. Optional search by name is supported.")
    public ResponseEntity<List<HostelDTO>> getAllHostels(
            @Parameter(description = "Search filter for hostel name")
            @RequestParam(required = false) String name) {
        if (name != null && !name.trim().isEmpty()) {
            return ResponseEntity.ok(hostelService.searchHostelsByName(name));
        }
        return ResponseEntity.ok(hostelService.getAllHostels());
    }

    @GetMapping("/{id}/stats")
    @Operation(summary = "Get hostel statistics", description = "Calculates total capacity, current occupancy, occupied/vacant rooms and percentage.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Stats calculated successfully"),
            @ApiResponse(responseCode = "404", description = "Hostel not found")
    })
    public ResponseEntity<HostelStatsResponse> getHostelStats(
            @Parameter(description = "ID of the hostel for which stats are calculated", required = true)
            @PathVariable String id) {
        return ResponseEntity.ok(hostelService.getHostelStats(id));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a hostel", description = "Updates details of an existing hostel.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Hostel updated successfully"),
            @ApiResponse(responseCode = "404", description = "Hostel not found")
    })
    public ResponseEntity<HostelDTO> updateHostel(
            @Parameter(description = "ID of the hostel to update", required = true)
            @PathVariable String id,
            @Valid @RequestBody HostelDTO dto) {
        return ResponseEntity.ok(hostelService.updateHostel(id, dto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a hostel", description = "Deletes a hostel. Cannot be deleted if rooms are assigned to it.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Hostel deleted successfully"),
            @ApiResponse(responseCode = "400", description = "Hostel has active rooms"),
            @ApiResponse(responseCode = "404", description = "Hostel not found")
    })
    public ResponseEntity<Void> deleteHostel(
            @Parameter(description = "ID of the hostel to delete", required = true)
            @PathVariable String id) {
        hostelService.deleteHostel(id);
        return ResponseEntity.noContent().build();
    }
}
