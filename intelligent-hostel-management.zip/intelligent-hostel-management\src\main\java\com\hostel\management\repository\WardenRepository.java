package com.hostel.management.repository;

import com.hostel.management.model.Warden;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface WardenRepository extends MongoRepository<Warden, String> {
    List<Warden> findByHostelId(String hostelId);
}
