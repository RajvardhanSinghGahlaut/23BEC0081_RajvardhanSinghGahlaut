package com.hostel.management.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HostelCardDTO {
    private String cardId;
    private String cardNumber;
    private LocalDate issueDate;
    private String studentId;
}
