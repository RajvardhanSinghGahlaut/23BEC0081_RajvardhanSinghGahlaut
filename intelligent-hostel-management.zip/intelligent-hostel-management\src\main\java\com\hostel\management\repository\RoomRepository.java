package com.hostel.management.repository;

import com.hostel.management.model.Room;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface RoomRepository extends MongoRepository<Room, String> {
    List<Room> findByHostelId(String hostelId);
    Optional<Room> findByHostelIdAndRoomNumber(String hostelId, String roomNumber);
    List<Room> findByRoomNumber(String roomNumber);
    List<Room> findByRoomNumberContainingIgnoreCase(String roomNumber);
}
