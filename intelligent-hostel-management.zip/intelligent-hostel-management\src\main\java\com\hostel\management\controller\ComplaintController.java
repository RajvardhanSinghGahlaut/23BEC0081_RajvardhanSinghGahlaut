package com.hostel.management.controller;

import com.hostel.management.dto.ComplaintDTO;
import com.hostel.management.dto.ComplaintStatusUpdateRequest;
import com.hostel.management.model.ComplaintStatus;
import com.hostel.management.service.ComplaintService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/complaints")
@RequiredArgsConstructor
@Tag(name = "Complaint Management", description = "Endpoints for student complaints and status workflows")
public class ComplaintController {

    private final ComplaintService complaintService;

    @PostMapping
    @Operation(summary = "Create a complaint", description = "Files a new complaint. Default status is PENDING.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Complaint registered successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid payload"),
            @ApiResponse(responseCode = "404", description = "Student not found")
    })
    public ResponseEntity<ComplaintDTO> createComplaint(@Valid @RequestBody ComplaintDTO dto) {
        return new ResponseEntity<>(complaintService.createComplaint(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get complaint by ID", description = "Fetches details of a specific complaint.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Complaint found"),
            @ApiResponse(responseCode = "404", description = "Complaint not found")
    })
    public ResponseEntity<ComplaintDTO> getComplaintById(
            @Parameter(description = "ID of the complaint to retrieve", required = true)
            @PathVariable String id) {
        return ResponseEntity.ok(complaintService.getComplaintById(id));
    }

    @GetMapping
    @Operation(summary = "Get all complaints", description = "Retrieves all complaints. Optional filtering by status is supported.")
    public ResponseEntity<List<ComplaintDTO>> getAllComplaints(
            @Parameter(description = "Filter complaints by status (PENDING, IN_PROGRESS, RESOLVED)")
            @RequestParam(required = false) ComplaintStatus status) {
        if (status != null) {
            return ResponseEntity.ok(complaintService.searchComplaintsByStatus(status));
        }
        return ResponseEntity.ok(complaintService.getAllComplaints());
    }

    @GetMapping("/student/{studentId}")
    @Operation(summary = "Get complaints by student ID", description = "Retrieves the complaint history filed by a specific student.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "List of complaints"),
            @ApiResponse(responseCode = "404", description = "Student not found")
    })
    public ResponseEntity<List<ComplaintDTO>> getComplaintsByStudent(
            @Parameter(description = "ID of the student to fetch complaints for", required = true)
            @PathVariable String studentId) {
        return ResponseEntity.ok(complaintService.getComplaintsByStudent(studentId));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Update complaint status", description = "Updates status of a complaint (PENDING -> IN_PROGRESS -> RESOLVED).")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Complaint status updated successfully"),
            @ApiResponse(responseCode = "404", description = "Complaint not found")
    })
    public ResponseEntity<ComplaintDTO> updateComplaintStatus(
            @Parameter(description = "ID of the complaint to update", required = true)
            @PathVariable String id,
            @Valid @RequestBody ComplaintStatusUpdateRequest request) {
        return ResponseEntity.ok(complaintService.updateComplaintStatus(id, request.getStatus()));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a complaint", description = "Deletes a complaint from the database.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Complaint deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Complaint not found")
    })
    public ResponseEntity<Void> deleteComplaint(
            @Parameter(description = "ID of the complaint to delete", required = true)
            @PathVariable String id) {
        complaintService.deleteComplaint(id);
        return ResponseEntity.noContent().build();
    }
}
