package com.hostel.management.repository;

import com.hostel.management.model.Hostel;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface HostelRepository extends MongoRepository<Hostel, String> {
    Optional<Hostel> findByHostelName(String hostelName);
    List<Hostel> findByHostelNameContainingIgnoreCase(String hostelName);
}
