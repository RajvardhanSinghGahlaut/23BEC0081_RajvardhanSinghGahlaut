package com.hostel.management.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "rooms")
public class Room {

    @Id
    private String roomId;
    
    private String roomNumber;
    
    private int capacity;
    
    private int currentOccupancy;
    
    private String roomType; // SINGLE, DOUBLE, TRIPLE, etc.
    
    private String hostelId; // Reference to Hostel
    
    private String wardenId; // Reference to Warden
}
