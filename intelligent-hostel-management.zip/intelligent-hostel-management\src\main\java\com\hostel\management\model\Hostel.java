package com.hostel.management.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "hostels")
public class Hostel {

    @Id
    private String hostelId;
    
    private String hostelName;
    
    private String hostelType; // BOYS, GIRLS, MIXED
    
    private int totalRooms;
    
    private int occupiedRooms; // Number of rooms with currentOccupancy > 0
    
    private int vacancyCount;  // Number of rooms with currentOccupancy < capacity
}
