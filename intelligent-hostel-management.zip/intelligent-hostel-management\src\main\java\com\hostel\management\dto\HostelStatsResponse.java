package com.hostel.management.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HostelStatsResponse {
    private String hostelId;
    private String hostelName;
    private int totalRooms;
    private int occupiedRooms;
    private int vacantRooms;
    private int totalCapacity;
    private int currentOccupancy;
    private int vacantBeds;
    private double occupancyPercentage;
}
