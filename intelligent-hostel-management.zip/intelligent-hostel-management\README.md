# Intelligent Hostel Resource Allocation and Resident Management System

A production-ready REST API-based Hostel Management System built with **Java 21**, **Spring Boot 3.x**, and **MongoDB**. The project implements a complete layered architecture, OpenAPI/Swagger documentation, data validation, dynamic room allocations, transfer workflows, and live occupancy statistics.

---

## 1. Project Architecture

The application is structured following the industry-standard clean layered architecture for Java backend services:

```
com.hostel.management/
├── HostelManagementApplication.java (Main Entrypoint)
├── config/                          (App configurations: MongoDB and Swagger OpenAPI)
├── controller/                      (REST Controllers with OpenAPI annotations)
├── service/                         (Core Business Logic and calculations)
├── repository/                      (Data access repositories extending MongoRepository)
├── model/                           (MongoDB document entities and database indexes)
├── dto/                             (Request and response data transfer objects)
└── exception/                       (Global exceptions and @ControllerAdvice handler)
```

### Layer Rationale
* **Controller Layer**: Exposes endpoints, coordinates URL parameters/query parameters, and delegates inputs to the Service layer. Annotations validate payloads (`@Valid`) and configure OpenAPI documentation.
* **Service Layer**: House of business logic. Orchestrates transaction boundaries, executes validations (e.g., room vacancy, registration uniqueness), manages relationships, and performs calculations.
* **Repository Layer**: Extends `MongoRepository` to handle standard and custom MongoDB queries.
* **Model Layer**: Maps Java classes directly to MongoDB collections (`students`, `hostels`, `rooms`, `wardens`, `hostel_cards`, `complaints`, `visitors`).
* **DTO Layer**: Decouples database entities from API request and response structures. Protects internal fields and contains validation constraints (`@Email`, `@Pattern`, `@NotBlank`, etc.).
* **Exception Handling Layer**: Leverages a global `@ControllerAdvice` advice wrapper (`GlobalExceptionHandler`) to translate custom exceptions (e.g., `RoomFullException`, `DuplicateResourceException`) into standardized JSON error responses.

---

## 2. MongoDB Schema & Database Relationships

MongoDB is configured to automatically build and manage indexes (e.g., `student.registrationNumber` and `hostelCard.cardNumber` are unique).

```mermaid
erDiagram
    Hostel ||--o{ Room : "has (One-to-Many)"
    Room ||--o{ Student : "occupies (One-to-Many)"
    Student ||--|| HostelCard : "holds (One-to-One)"
    Student ||--o{ Complaint : "files (One-to-Many)"
    Student }o--o{ Visitor : "receives (Many-to-Many)"
    Room }o--|| Warden : "assigned-to (Many-to-One)"
```

### Collections Design
1. **Hostels (`hostels`)**
   - Represents a physical building. Includes counters for rooms and occupancy.
   - Relationships: One-to-Many references to Rooms.
2. **Rooms (`rooms`)**
   - Represents a room inside a hostel. Stores room capacity and current resident counts.
   - Relationships: Many-to-One with Hostel (`hostelId`), Many-to-One with Warden (`wardenId`).
3. **Students (`students`)**
   - Represents a resident. Stores profile data and links to a specific room, hostel, and hostel card.
   - Relationships: One-to-One with `HostelCard` (`hostelCardId`), Many-to-One with `Room` (`roomId`), Many-to-One with `Hostel` (`hostelId`).
4. **Wardens (`wardens`)**
   - Represents staff members managing hostels.
   - Relationships: Many-to-One with Hostel (`hostelId`).
5. **HostelCards (`hostel_cards`)**
   - Holds security access cards issued to students upon registration.
   - Relationships: One-to-One with `Student` (`studentId`).
6. **Complaints (`complaints`)**
   - Represents issues logged by residents.
   - Relationships: Many-to-One with `Student` (`studentId`).
7. **Visitors (`visitors`)**
   - Represents guests checking in and out of the hostel.
   - Relationships: Many-to-Many log history with `Student` (`studentId`).

---

## 3. Core Business Workflows

### A. Automatic Room Allocation
When registering a new student via `POST /api/students`:
* **Option 1**: A specific `roomId` is requested. The system verifies the room exists, validates that the room is not already full (`currentOccupancy < capacity`), and increments the room's occupancy.
* **Option 2**: A `hostelId` is requested. The system searches for the first room within that hostel containing vacancy, sets the student's room, and increments the room's occupancy.
* **Option 3**: No room details are provided. The system searches all rooms globally for any vacant bed.
* If no rooms have vacancy, a `RoomFullException` is thrown.
* A `HostelCard` is automatically created with the format `CARD-<REG_NUM>` and linked to the student.
* Hostel statistic counters (`occupiedRooms`, `vacancyCount`) are updated dynamically.

### B. Room Transfer Workflow
When moving a student via `PUT /api/students/{id}/transfer`:
* The system verifies the student and target room exist.
* The target room is checked for vacancy.
* The student's current room has its occupancy decremented.
* The target room has its occupancy incremented.
* The student's profile is updated with the new `roomId` and `hostelId`.
* Occupancy statistics for the involved hostels are recalculated dynamically.

### C. Live Occupancy Monitoring
Provides a dedicated API `/api/hostels/{id}/stats` that calculates:
* `totalRooms`: Total count of rooms.
* `occupiedRooms`: Count of rooms with at least 1 resident.
* `vacantRooms`: Count of rooms with open capacity.
* `totalCapacity`: Sum of all beds (capacity) in the hostel.
* `currentOccupancy`: Total number of active residents in the hostel.
* `vacantBeds`: Available spaces for allocation.
* `occupancyPercentage`: Percentage of total capacity filled.

---

## 4. API Documentation & OpenAPI Spec

When the application is running, the interactive Swagger documentation is available at:
👉 **Swagger UI:** `http://localhost:8080/swagger-ui.html`
👉 **Raw JSON Specs:** `http://localhost:8080/v3/api-docs`

### Summary of Endpoints

| Category | Method | Path | Description |
| :--- | :--- | :--- | :--- |
| **Hostels** | `POST` | `/api/hostels` | Create a new hostel |
| | `GET` | `/api/hostels` | Get all hostels (Optional query `name` search) |
| | `GET` | `/api/hostels/{id}` | Get hostel by ID |
| | `GET` | `/api/hostels/{id}/stats` | Get occupancy stats for a hostel |
| | `PUT` | `/api/hostels/{id}` | Update hostel details |
| | `DELETE`| `/api/hostels/{id}` | Delete hostel (Requires no active rooms) |
| **Rooms** | `POST` | `/api/rooms` | Create a new room in a hostel |
| | `GET` | `/api/rooms` | Get all rooms (Optional query `roomNumber` search) |
| | `GET` | `/api/rooms/{id}` | Get room by ID |
| | `PUT` | `/api/rooms/{id}` | Update room details (Capacity validations) |
| | `DELETE`| `/api/rooms/{id}` | Delete room (Requires no active residents) |
| **Students** | `POST` | `/api/students` | Register student (Auto-allocates room & card) |
| | `GET` | `/api/students` | Get all students (Optional query `regNum` search) |
| | `GET` | `/api/students/{id}` | Get student by ID |
| | `PUT` | `/api/students/{id}` | Update profile details (Name, email, phone) |
| | `PUT` | `/api/students/{id}/transfer` | Transfer student to another room |
| | `DELETE`| `/api/students/{id}` | Delete resident (Releases room occupancy & card) |
| **Wardens** | `POST` | `/api/wardens` | Register a new hostel warden |
| | `GET` | `/api/wardens` | Get all wardens |
| | `GET` | `/api/wardens/{id}` | Get warden by ID |
| | `PUT` | `/api/wardens/{id}` | Update warden details |
| | `DELETE`| `/api/wardens/{id}` | Delete warden |
| **Complaints**| `POST` | `/api/complaints` | File a complaint (Defaults to PENDING) |
| | `GET` | `/api/complaints` | Get all complaints (Optional query `status` filter) |
| | `GET` | `/api/complaints/student/{id}`| Get complaint history for a student |
| | `PATCH`| `/api/complaints/{id}/status`| Update status (PENDING, IN_PROGRESS, RESOLVED) |
| | `DELETE`| `/api/complaints/{id}` | Delete complaint record |
| **Visitors** | `POST` | `/api/visitors/entry` | Register visitor entry (Sets entry timestamp) |
| | `PATCH`| `/api/visitors/{id}/exit` | Register visitor exit (Sets exit timestamp) |
| | `GET` | `/api/visitors/history` | Get visitor logs (Optional query `studentId` filter) |
| | `DELETE`| `/api/visitors/{id}` | Delete visitor record |

---

## 5. Sample JSON Payloads for Postman Testing

### 1. Hostels API (`POST /api/hostels`)
```json
{
  "hostelName": "Newton Boys Hostel",
  "hostelType": "BOYS",
  "totalRooms": 50
}
```

### 2. Wardens API (`POST /api/wardens`)
```json
{
  "name": "Prof. Robert Thorne",
  "email": "robert.thorne@hostel.com",
  "phoneNumber": "9876543210",
  "hostelId": "651f80164c01ff3a7894bc21"
}
```

### 3. Rooms API (`POST /api/rooms`)
```json
{
  "roomNumber": "101",
  "capacity": 3,
  "roomType": "TRIPLE",
  "hostelId": "651f80164c01ff3a7894bc21",
  "wardenId": "651f80874c01ff3a7894bc22"
}
```

### 4. Students API (`POST /api/students`)
```json
{
  "registrationNumber": "CS20261001",
  "name": "Alex Mercer",
  "email": "alex.mercer@univ.edu",
  "phoneNumber": "8877665544",
  "gender": "MALE",
  "department": "Computer Science",
  "hostelId": "651f80164c01ff3a7894bc21"
}
```

### 5. Room Transfer (`PUT /api/students/{studentId}/transfer`)
```json
{
  "targetRoomId": "651f80bb4c01ff3a7894bc23"
}
```

### 6. Complaints API (`POST /api/complaints`)
```json
{
  "studentId": "651f81014c01ff3a7894bc24",
  "title": "Wi-Fi Connectivity Issue",
  "description": "Internet connection is down or extremely slow on the first floor since yesterday evening."
}
```

### 7. Complaint Status Update (`PATCH /api/complaints/{id}/status`)
```json
{
  "status": "IN_PROGRESS"
}
```

### 8. Visitor Entry Log (`POST /api/visitors/entry`)
```json
{
  "visitorName": "John Mercer",
  "phoneNumber": "7766554433",
  "studentId": "651f81014c01ff3a7894bc24"
}
```

---

## 6. How to Build and Run Locally

### Prerequisites
1. **Java SDK 21** or later.
2. **MongoDB Community Server** running locally on port `27017` (or configured remotely).
3. **Maven** (configured on path, or use local installation path).

### Steps
1. **Clone the Repository** and navigate to the root directory.
2. **Verify Database Configuration**: Check the `src/main/resources/application.yml` file to ensure the MongoDB URI matches your setup:
   ```yaml
   spring:
     data:
       mongodb:
         uri: mongodb://localhost:27017/hostel_db
   ```
3. **Build and Compile the Project**:
   ```bash
   mvn clean package
   ```
4. **Run the Application**:
   ```bash
   mvn spring-boot:run
   ```
5. Open your browser and navigate to the Swagger Documentation UI:
   `http://localhost:8080/swagger-ui.html`
