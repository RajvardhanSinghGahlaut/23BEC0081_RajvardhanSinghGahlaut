package com.hostel.management.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "complaints")
public class Complaint {

    @Id
    private String complaintId;
    
    private String studentId; // Reference to Student
    
    private String title;
    
    private String description;
    
    private LocalDateTime complaintDate;
    
    private ComplaintStatus status; // PENDING, IN_PROGRESS, RESOLVED
}
