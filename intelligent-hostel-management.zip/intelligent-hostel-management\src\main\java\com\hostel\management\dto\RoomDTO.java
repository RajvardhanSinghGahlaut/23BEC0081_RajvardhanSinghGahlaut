package com.hostel.management.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RoomDTO {
    private String roomId;

    @NotBlank(message = "Room number is mandatory")
    private String roomNumber;

    @NotNull(message = "Capacity is mandatory")
    @Min(value = 1, message = "Capacity must be at least 1")
    private Integer capacity;

    private int currentOccupancy;

    @NotBlank(message = "Room type is mandatory (e.g. SINGLE, DOUBLE, TRIPLE)")
    private String roomType;

    @NotBlank(message = "Hostel ID is mandatory")
    private String hostelId;

    private String wardenId;
}
