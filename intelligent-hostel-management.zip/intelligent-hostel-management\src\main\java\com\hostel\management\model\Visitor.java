package com.hostel.management.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "visitors")
public class Visitor {

    @Id
    private String visitorId;
    
    private String visitorName;
    
    private String phoneNumber;
    
    private String studentId; // Reference to Student
    
    private LocalDateTime entryTime;
    
    private LocalDateTime exitTime;
}
