package com.hostel.management.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HostelDTO {
    private String hostelId;

    @NotBlank(message = "Hostel name is mandatory")
    private String hostelName;

    @NotBlank(message = "Hostel type is mandatory (e.g. BOYS, GIRLS, MIXED)")
    private String hostelType;

    @NotNull(message = "Total rooms is mandatory")
    @Min(value = 1, message = "Total rooms must be at least 1")
    private Integer totalRooms;

    private int occupiedRooms;
    
    private int vacancyCount;
}
