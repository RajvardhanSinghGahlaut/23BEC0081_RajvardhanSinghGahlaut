package com.hostel.management.model;

public enum ComplaintStatus {
    PENDING,
    IN_PROGRESS,
    RESOLVED
}
