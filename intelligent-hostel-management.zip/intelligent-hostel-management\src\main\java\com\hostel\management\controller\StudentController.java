package com.hostel.management.controller;

import com.hostel.management.dto.RoomTransferRequest;
import com.hostel.management.dto.StudentDTO;
import com.hostel.management.service.StudentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
@Tag(name = "Student Management", description = "Endpoints for managing student profiles, room auto-allocations, and transfers")
public class StudentController {

    private final StudentService studentService;

    @PostMapping
    @Operation(summary = "Register a new student", description = "Registers a student and auto-allocates a room if vacancy exists. Automatically issues a Hostel Card.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Student registered and allocated successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid payload or room is full"),
            @ApiResponse(responseCode = "409", description = "Registration number already exists")
    })
    public ResponseEntity<StudentDTO> createStudent(@Valid @RequestBody StudentDTO dto) {
        return new ResponseEntity<>(studentService.createStudent(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get student by ID", description = "Fetches profile details of a specific student.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Student found"),
            @ApiResponse(responseCode = "404", description = "Student not found")
    })
    public ResponseEntity<StudentDTO> getStudentById(
            @Parameter(description = "ID of the student to retrieve", required = true)
            @PathVariable String id) {
        return ResponseEntity.ok(studentService.getStudentById(id));
    }

    @GetMapping
    @Operation(summary = "Get all students", description = "Retrieves all students. Optional search by registration number is supported.")
    public ResponseEntity<List<StudentDTO>> getAllStudents(
            @Parameter(description = "Search filter for student registration number")
            @RequestParam(required = false) String regNum) {
        if (regNum != null && !regNum.trim().isEmpty()) {
            return ResponseEntity.ok(List.of(studentService.getStudentByRegistrationNumber(regNum)));
        }
        return ResponseEntity.ok(studentService.getAllStudents());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update student profile", description = "Updates general profile details like name, email, phone, gender, and department. Does not perform room changes.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Student profile updated successfully"),
            @ApiResponse(responseCode = "404", description = "Student not found"),
            @ApiResponse(responseCode = "409", description = "Registration number already in use")
    })
    public ResponseEntity<StudentDTO> updateStudent(
            @Parameter(description = "ID of the student to update", required = true)
            @PathVariable String id,
            @Valid @RequestBody StudentDTO dto) {
        return ResponseEntity.ok(studentService.updateStudent(id, dto));
    }

    @PutMapping("/{id}/transfer")
    @Operation(summary = "Transfer student to another room", description = "Transfers a resident student to another room. Handles occupancy count increments/decrements dynamically.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Student transferred successfully"),
            @ApiResponse(responseCode = "400", description = "Target room is full"),
            @ApiResponse(responseCode = "404", description = "Student or Target Room not found")
    })
    public ResponseEntity<StudentDTO> transferStudentRoom(
            @Parameter(description = "ID of the student to transfer", required = true)
            @PathVariable String id,
            @Valid @RequestBody RoomTransferRequest request) {
        return ResponseEntity.ok(studentService.transferStudentRoom(id, request.getTargetRoomId()));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete student registration", description = "Deletes a student. Automatically releases room occupancy and voids the Hostel Card.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Student deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Student not found")
    })
    public ResponseEntity<Void> deleteStudent(
            @Parameter(description = "ID of the student to delete", required = true)
            @PathVariable String id) {
        studentService.deleteStudent(id);
        return ResponseEntity.noContent().build();
    }
}
