package com.hostel.management.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "wardens")
public class Warden {

    @Id
    private String wardenId;
    
    private String name;
    
    private String email;
    
    private String phoneNumber;
    
    private String hostelId; // Reference to Hostel
}
