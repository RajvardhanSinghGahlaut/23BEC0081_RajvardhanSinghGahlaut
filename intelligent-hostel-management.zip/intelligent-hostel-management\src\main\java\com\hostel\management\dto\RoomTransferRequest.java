package com.hostel.management.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RoomTransferRequest {
    @NotBlank(message = "Target Room ID is mandatory")
    private String targetRoomId;
}
