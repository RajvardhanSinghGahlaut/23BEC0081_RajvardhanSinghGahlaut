package com.hostel.management.controller;

import com.hostel.management.dto.WardenDTO;
import com.hostel.management.service.WardenService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/wardens")
@RequiredArgsConstructor
@Tag(name = "Warden Management", description = "Endpoints for managing Hostels Wardens")
public class WardenController {

    private final WardenService wardenService;

    @PostMapping
    @Operation(summary = "Create a new warden", description = "Registers a new warden in the system.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Warden created successfully"),
            @ApiResponse(responseCode = "400", description = "Invalid request payload"),
            @ApiResponse(responseCode = "404", description = "Hostel not found")
    })
    public ResponseEntity<WardenDTO> createWarden(@Valid @RequestBody WardenDTO dto) {
        return new ResponseEntity<>(wardenService.createWarden(dto), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get warden by ID", description = "Fetches details of a specific warden.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Warden found"),
            @ApiResponse(responseCode = "404", description = "Warden not found")
    })
    public ResponseEntity<WardenDTO> getWardenById(
            @Parameter(description = "ID of the warden to retrieve", required = true)
            @PathVariable String id) {
        return ResponseEntity.ok(wardenService.getWardenById(id));
    }

    @GetMapping
    @Operation(summary = "Get all wardens", description = "Retrieves all wardens registered in the system.")
    public ResponseEntity<List<WardenDTO>> getAllWardens() {
        return ResponseEntity.ok(wardenService.getAllWardens());
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a warden", description = "Updates details of an existing warden.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Warden updated successfully"),
            @ApiResponse(responseCode = "404", description = "Warden or Hostel not found")
    })
    public ResponseEntity<WardenDTO> updateWarden(
            @Parameter(description = "ID of the warden to update", required = true)
            @PathVariable String id,
            @Valid @RequestBody WardenDTO dto) {
        return ResponseEntity.ok(wardenService.updateWarden(id, dto));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a warden", description = "Deletes a warden from the system.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Warden deleted successfully"),
            @ApiResponse(responseCode = "404", description = "Warden not found")
    })
    public ResponseEntity<Void> deleteWarden(
            @Parameter(description = "ID of the warden to delete", required = true)
            @PathVariable String id) {
        wardenService.deleteWarden(id);
        return ResponseEntity.noContent().build();
    }
}
