package com.hostel.management.service;

import com.hostel.management.dto.RoomDTO;
import com.hostel.management.exception.BadRequestException;
import com.hostel.management.exception.ResourceNotFoundException;
import com.hostel.management.model.Room;
import com.hostel.management.repository.HostelRepository;
import com.hostel.management.repository.RoomRepository;
import com.hostel.management.repository.WardenRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RoomService {

    private final RoomRepository roomRepository;
    private final HostelRepository hostelRepository;
    private final WardenRepository wardenRepository;
    private final HostelService hostelService;

    public RoomDTO createRoom(RoomDTO dto) {
        if (!hostelRepository.existsById(dto.getHostelId())) {
            throw new ResourceNotFoundException("Hostel not found with id: " + dto.getHostelId());
        }

        if (dto.getWardenId() != null && !dto.getWardenId().isEmpty()) {
            if (!wardenRepository.existsById(dto.getWardenId())) {
                throw new ResourceNotFoundException("Warden not found with id: " + dto.getWardenId());
            }
        }

        // Check if room number is unique within the same hostel
        if (roomRepository.findByHostelIdAndRoomNumber(dto.getHostelId(), dto.getRoomNumber()).isPresent()) {
            throw new BadRequestException("Room number " + dto.getRoomNumber() + " already exists in this hostel.");
        }

        Room room = Room.builder()
                .roomNumber(dto.getRoomNumber())
                .capacity(dto.getCapacity())
                .currentOccupancy(0)
                .roomType(dto.getRoomType())
                .hostelId(dto.getHostelId())
                .wardenId(dto.getWardenId())
                .build();

        room = roomRepository.save(room);
        hostelService.updateHostelStats(dto.getHostelId());
        return convertToDTO(room);
    }

    public RoomDTO getRoomById(String roomId) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + roomId));
        return convertToDTO(room);
    }

    public List<RoomDTO> getAllRooms() {
        return roomRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<RoomDTO> searchRoomsByNumber(String roomNumber) {
        return roomRepository.findByRoomNumberContainingIgnoreCase(roomNumber).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public RoomDTO updateRoom(String roomId, RoomDTO dto) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + roomId));

        if (!hostelRepository.existsById(dto.getHostelId())) {
            throw new ResourceNotFoundException("Hostel not found with id: " + dto.getHostelId());
        }

        if (dto.getWardenId() != null && !dto.getWardenId().isEmpty()) {
            if (!wardenRepository.existsById(dto.getWardenId())) {
                throw new ResourceNotFoundException("Warden not found with id: " + dto.getWardenId());
            }
        }

        // Capacity check: Cannot update capacity to be less than current occupancy
        if (dto.getCapacity() < room.getCurrentOccupancy()) {
            throw new BadRequestException("Cannot set capacity to " + dto.getCapacity() + 
                    " because current occupancy is already " + room.getCurrentOccupancy());
        }

        // Check if room number conflict exists in the same hostel
        roomRepository.findByHostelIdAndRoomNumber(dto.getHostelId(), dto.getRoomNumber())
                .ifPresent(existingRoom -> {
                    if (!existingRoom.getRoomId().equals(roomId)) {
                        throw new BadRequestException("Room number " + dto.getRoomNumber() + " already exists in this hostel.");
                    }
                });

        String oldHostelId = room.getHostelId();
        
        room.setRoomNumber(dto.getRoomNumber());
        room.setCapacity(dto.getCapacity());
        room.setRoomType(dto.getRoomType());
        room.setHostelId(dto.getHostelId());
        room.setWardenId(dto.getWardenId());

        room = roomRepository.save(room);
        
        // Update statistics for both old and new hostels (if they differ)
        hostelService.updateHostelStats(dto.getHostelId());
        if (!oldHostelId.equals(dto.getHostelId())) {
            hostelService.updateHostelStats(oldHostelId);
        }
        
        return convertToDTO(room);
    }

    public void deleteRoom(String roomId) {
        Room room = roomRepository.findById(roomId)
                .orElseThrow(() -> new ResourceNotFoundException("Room not found with id: " + roomId));

        if (room.getCurrentOccupancy() > 0) {
            throw new BadRequestException("Cannot delete room with active residents. Current occupancy: " + room.getCurrentOccupancy());
        }

        roomRepository.delete(room);
        hostelService.updateHostelStats(room.getHostelId());
    }

    private RoomDTO convertToDTO(Room room) {
        return RoomDTO.builder()
                .roomId(room.getRoomId())
                .roomNumber(room.getRoomNumber())
                .capacity(room.getCapacity())
                .currentOccupancy(room.getCurrentOccupancy())
                .roomType(room.getRoomType())
                .hostelId(room.getHostelId())
                .wardenId(room.getWardenId())
                .build();
    }
}
