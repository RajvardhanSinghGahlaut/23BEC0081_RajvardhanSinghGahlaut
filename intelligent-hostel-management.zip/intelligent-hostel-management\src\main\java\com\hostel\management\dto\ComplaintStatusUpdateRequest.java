package com.hostel.management.dto;

import com.hostel.management.model.ComplaintStatus;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ComplaintStatusUpdateRequest {
    @NotNull(message = "Status is mandatory")
    private ComplaintStatus status;
}
