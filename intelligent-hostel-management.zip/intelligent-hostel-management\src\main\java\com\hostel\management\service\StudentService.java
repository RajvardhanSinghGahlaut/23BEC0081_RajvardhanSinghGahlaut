package com.hostel.management.service;

import com.hostel.management.dto.StudentDTO;
import com.hostel.management.exception.BadRequestException;
import com.hostel.management.exception.DuplicateResourceException;
import com.hostel.management.exception.ResourceNotFoundException;
import com.hostel.management.exception.RoomFullException;
import com.hostel.management.model.HostelCard;
import com.hostel.management.model.Room;
import com.hostel.management.model.Student;
import com.hostel.management.repository.HostelCardRepository;
import com.hostel.management.repository.HostelRepository;
import com.hostel.management.repository.RoomRepository;
import com.hostel.management.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class StudentService {

    private final StudentRepository studentRepository;
    private final RoomRepository roomRepository;
    private final HostelRepository hostelRepository;
    private final HostelCardRepository hostelCardRepository;
    private final HostelService hostelService;

    @Transactional
    public StudentDTO createStudent(StudentDTO dto) {
        // 1. Verify Registration Number Uniqueness
        if (studentRepository.existsByRegistrationNumber(dto.getRegistrationNumber())) {
            throw new DuplicateResourceException("Student with registration number " + 
                    dto.getRegistrationNumber() + " already exists.");
        }

        // 2. Allocate Room
        Room allocatedRoom = determineAndAllocateRoom(dto);
        
        // 3. Increment Room Occupancy
        allocatedRoom.setCurrentOccupancy(allocatedRoom.getCurrentOccupancy() + 1);
        roomRepository.save(allocatedRoom);

        // 4. Create Student Entity
        Student student = Student.builder()
                .registrationNumber(dto.getRegistrationNumber())
                .name(dto.getName())
                .email(dto.getEmail())
                .phoneNumber(dto.getPhoneNumber())
                .gender(dto.getGender())
                .department(dto.getDepartment())
                .roomId(allocatedRoom.getRoomId())
                .hostelId(allocatedRoom.getHostelId())
                .build();
        
        student = studentRepository.save(student);

        // 5. Generate and Link Hostel Card
        String cardNumber = "CARD-" + student.getRegistrationNumber().toUpperCase();
        HostelCard card = HostelCard.builder()
                .cardNumber(cardNumber)
                .issueDate(LocalDate.now())
                .studentId(student.getStudentId())
                .build();
        card = hostelCardRepository.save(card);

        // Update Student with Card ID
        student.setHostelCardId(card.getCardId());
        student = studentRepository.save(student);

        // 6. Update Hostel Stats
        hostelService.updateHostelStats(allocatedRoom.getHostelId());

        return convertToDTO(student);
    }

    private Room determineAndAllocateRoom(StudentDTO dto) {
        // Scenario A: Specific Room ID provided
        if (dto.getRoomId() != null && !dto.getRoomId().isEmpty()) {
            Room room = roomRepository.findById(dto.getRoomId())
                    .orElseThrow(() -> new ResourceNotFoundException("Room not found with ID: " + dto.getRoomId()));
            if (room.getCurrentOccupancy() >= room.getCapacity()) {
                throw new RoomFullException("Requested Room " + room.getRoomNumber() + " is full.");
            }
            return room;
        }

        // Scenario B: Specific Hostel ID provided, find first vacant room
        if (dto.getHostelId() != null && !dto.getHostelId().isEmpty()) {
            if (!hostelRepository.existsById(dto.getHostelId())) {
                throw new ResourceNotFoundException("Hostel not found with ID: " + dto.getHostelId());
            }
            List<Room> rooms = roomRepository.findByHostelId(dto.getHostelId());
            for (Room room : rooms) {
                if (room.getCurrentOccupancy() < room.getCapacity()) {
                    return room;
                }
            }
            throw new RoomFullException("No rooms are vacant in the requested hostel.");
        }

        // Scenario C: Neither room nor hostel specified, find any vacant room in the database
        List<Room> allRooms = roomRepository.findAll();
        for (Room room : allRooms) {
            if (room.getCurrentOccupancy() < room.getCapacity()) {
                return room;
            }
        }
        
        throw new RoomFullException("No vacant rooms are available in any hostel.");
    }

    public StudentDTO getStudentById(String studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + studentId));
        return convertToDTO(student);
    }

    public StudentDTO getStudentByRegistrationNumber(String regNum) {
        Student student = studentRepository.findByRegistrationNumber(regNum)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with registration number: " + regNum));
        return convertToDTO(student);
    }

    public List<StudentDTO> getAllStudents() {
        return studentRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public StudentDTO updateStudent(String studentId, StudentDTO dto) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + studentId));

        // Validate registration number if changed
        if (!student.getRegistrationNumber().equalsIgnoreCase(dto.getRegistrationNumber())) {
            if (studentRepository.existsByRegistrationNumber(dto.getRegistrationNumber())) {
                throw new DuplicateResourceException("Registration number " + dto.getRegistrationNumber() + " is already in use.");
            }
            student.setRegistrationNumber(dto.getRegistrationNumber());
        }

        student.setName(dto.getName());
        student.setEmail(dto.getEmail());
        student.setPhoneNumber(dto.getPhoneNumber());
        student.setGender(dto.getGender());
        student.setDepartment(dto.getDepartment());

        student = studentRepository.save(student);
        return convertToDTO(student);
    }

    @Transactional
    public void deleteStudent(String studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + studentId));

        // 1. Release Room occupancy
        if (student.getRoomId() != null) {
            roomRepository.findById(student.getRoomId()).ifPresent(room -> {
                if (room.getCurrentOccupancy() > 0) {
                    room.setCurrentOccupancy(room.getCurrentOccupancy() - 1);
                    roomRepository.save(room);
                    hostelService.updateHostelStats(room.getHostelId());
                }
            });
        }

        // 2. Delete linked Hostel Card
        hostelCardRepository.deleteByStudentId(studentId);

        // 3. Delete Student record
        studentRepository.delete(student);
    }

    @Transactional
    public StudentDTO transferStudentRoom(String studentId, String targetRoomId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found with id: " + studentId));

        Room targetRoom = roomRepository.findById(targetRoomId)
                .orElseThrow(() -> new ResourceNotFoundException("Target Room not found with id: " + targetRoomId));

        if (targetRoom.getCurrentOccupancy() >= targetRoom.getCapacity()) {
            throw new RoomFullException("Target room " + targetRoom.getRoomNumber() + " is already full.");
        }

        String sourceRoomId = student.getRoomId();
        
        // If they are transferring to the same room, do nothing
        if (targetRoomId.equals(sourceRoomId)) {
            return convertToDTO(student);
        }

        // 1. Decrement old room occupancy
        if (sourceRoomId != null) {
            roomRepository.findById(sourceRoomId).ifPresent(oldRoom -> {
                if (oldRoom.getCurrentOccupancy() > 0) {
                    oldRoom.setCurrentOccupancy(oldRoom.getCurrentOccupancy() - 1);
                    roomRepository.save(oldRoom);
                    hostelService.updateHostelStats(oldRoom.getHostelId());
                }
            });
        }

        // 2. Increment target room occupancy
        targetRoom.setCurrentOccupancy(targetRoom.getCurrentOccupancy() + 1);
        roomRepository.save(targetRoom);

        // 3. Update Student Record
        student.setRoomId(targetRoom.getRoomId());
        student.setHostelId(targetRoom.getHostelId());
        student = studentRepository.save(student);

        // 4. Update stats for new hostel
        hostelService.updateHostelStats(targetRoom.getHostelId());

        return convertToDTO(student);
    }

    private StudentDTO convertToDTO(Student student) {
        return StudentDTO.builder()
                .studentId(student.getStudentId())
                .registrationNumber(student.getRegistrationNumber())
                .name(student.getName())
                .email(student.getEmail())
                .phoneNumber(student.getPhoneNumber())
                .gender(student.getGender())
                .department(student.getDepartment())
                .roomId(student.getRoomId())
                .hostelId(student.getHostelId())
                .hostelCardId(student.getHostelCardId())
                .build();
    }
}
