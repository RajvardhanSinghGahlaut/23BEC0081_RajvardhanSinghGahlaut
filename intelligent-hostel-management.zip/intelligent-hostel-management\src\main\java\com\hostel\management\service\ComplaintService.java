package com.hostel.management.service;

import com.hostel.management.dto.ComplaintDTO;
import com.hostel.management.exception.ResourceNotFoundException;
import com.hostel.management.model.Complaint;
import com.hostel.management.model.ComplaintStatus;
import com.hostel.management.repository.ComplaintRepository;
import com.hostel.management.repository.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ComplaintService {

    private final ComplaintRepository complaintRepository;
    private final StudentRepository studentRepository;

    public ComplaintDTO createComplaint(ComplaintDTO dto) {
        if (!studentRepository.existsById(dto.getStudentId())) {
            throw new ResourceNotFoundException("Student not found with id: " + dto.getStudentId());
        }

        Complaint complaint = Complaint.builder()
                .studentId(dto.getStudentId())
                .title(dto.getTitle())
                .description(dto.getDescription())
                .complaintDate(LocalDateTime.now())
                .status(ComplaintStatus.PENDING)
                .build();

        complaint = complaintRepository.save(complaint);
        return convertToDTO(complaint);
    }

    public ComplaintDTO getComplaintById(String complaintId) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found with id: " + complaintId));
        return convertToDTO(complaint);
    }

    public List<ComplaintDTO> getAllComplaints() {
        return complaintRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<ComplaintDTO> getComplaintsByStudent(String studentId) {
        if (!studentRepository.existsById(studentId)) {
            throw new ResourceNotFoundException("Student not found with id: " + studentId);
        }
        return complaintRepository.findByStudentId(studentId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<ComplaintDTO> searchComplaintsByStatus(ComplaintStatus status) {
        return complaintRepository.findByStatus(status).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public ComplaintDTO updateComplaintStatus(String complaintId, ComplaintStatus status) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found with id: " + complaintId));

        complaint.setStatus(status);
        complaint = complaintRepository.save(complaint);
        return convertToDTO(complaint);
    }

    public void deleteComplaint(String complaintId) {
        Complaint complaint = complaintRepository.findById(complaintId)
                .orElseThrow(() -> new ResourceNotFoundException("Complaint not found with id: " + complaintId));
        complaintRepository.delete(complaint);
    }

    private ComplaintDTO convertToDTO(Complaint complaint) {
        return ComplaintDTO.builder()
                .complaintId(complaint.getComplaintId())
                .studentId(complaint.getStudentId())
                .title(complaint.getTitle())
                .description(complaint.getDescription())
                .complaintDate(complaint.getComplaintDate())
                .status(complaint.getStatus())
                .build();
    }
}
