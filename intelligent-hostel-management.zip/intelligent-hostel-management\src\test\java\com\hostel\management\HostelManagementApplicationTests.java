package com.hostel.management;

import com.hostel.management.dto.StudentDTO;
import com.hostel.management.exception.RoomFullException;
import com.hostel.management.model.HostelCard;
import com.hostel.management.model.Room;
import com.hostel.management.model.Student;
import com.hostel.management.repository.HostelCardRepository;
import com.hostel.management.repository.HostelRepository;
import com.hostel.management.repository.RoomRepository;
import com.hostel.management.repository.StudentRepository;
import com.hostel.management.service.HostelService;
import com.hostel.management.service.StudentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class HostelManagementApplicationTests {

    @Mock
    private StudentRepository studentRepository;

    @Mock
    private RoomRepository roomRepository;

    @Mock
    private HostelRepository hostelRepository;

    @Mock
    private HostelCardRepository hostelCardRepository;

    @Mock
    private HostelService hostelService;

    @InjectMocks
    private StudentService studentService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateStudentSuccess() {
        // Arrange
        StudentDTO dto = StudentDTO.builder()
                .registrationNumber("REG123")
                .name("John Doe")
                .email("john.doe@email.com")
                .phoneNumber("1234567890")
                .gender("MALE")
                .department("CS")
                .roomId("room-1")
                .build();

        Room room = Room.builder()
                .roomId("room-1")
                .roomNumber("101")
                .capacity(2)
                .currentOccupancy(0)
                .hostelId("hostel-1")
                .build();

        Student student = Student.builder()
                .studentId("student-1")
                .registrationNumber("REG123")
                .name("John Doe")
                .roomId("room-1")
                .hostelId("hostel-1")
                .build();

        HostelCard card = HostelCard.builder()
                .cardId("card-1")
                .cardNumber("CARD-REG123")
                .studentId("student-1")
                .build();

        when(studentRepository.existsByRegistrationNumber("REG123")).thenReturn(false);
        when(roomRepository.findById("room-1")).thenReturn(Optional.of(room));
        when(roomRepository.save(any(Room.class))).thenReturn(room);
        when(studentRepository.save(any(Student.class))).thenReturn(student);
        when(hostelCardRepository.save(any(HostelCard.class))).thenReturn(card);

        // Act
        StudentDTO result = studentService.createStudent(dto);

        // Assert
        assertNotNull(result);
        assertEquals("REG123", result.getRegistrationNumber());
        assertEquals("student-1", result.getStudentId());
        verify(roomRepository, times(1)).save(any(Room.class));
        verify(studentRepository, times(2)).save(any(Student.class));
        verify(hostelCardRepository, times(1)).save(any(HostelCard.class));
        verify(hostelService, times(1)).updateHostelStats("hostel-1");
    }

    @Test
    void testCreateStudentRoomFullThrowsException() {
        // Arrange
        StudentDTO dto = StudentDTO.builder()
                .registrationNumber("REG123")
                .name("John Doe")
                .email("john.doe@email.com")
                .phoneNumber("1234567890")
                .gender("MALE")
                .department("CS")
                .roomId("room-1")
                .build();

        Room room = Room.builder()
                .roomId("room-1")
                .roomNumber("101")
                .capacity(2)
                .currentOccupancy(2) // Full!
                .hostelId("hostel-1")
                .build();

        when(studentRepository.existsByRegistrationNumber("REG123")).thenReturn(false);
        when(roomRepository.findById("room-1")).thenReturn(Optional.of(room));

        // Act & Assert
        assertThrows(RoomFullException.class, () -> studentService.createStudent(dto));
        verify(studentRepository, never()).save(any(Student.class));
    }
}
