package com.hostel.management.service;

import com.hostel.management.dto.VisitorDTO;
import com.hostel.management.exception.BadRequestException;
import com.hostel.management.exception.ResourceNotFoundException;
import com.hostel.management.model.Visitor;
import com.hostel.management.repository.StudentRepository;
import com.hostel.management.repository.VisitorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class VisitorService {

    private final VisitorRepository visitorRepository;
    private final StudentRepository studentRepository;

    public VisitorDTO createVisitorEntry(VisitorDTO dto) {
        if (!studentRepository.existsById(dto.getStudentId())) {
            throw new ResourceNotFoundException("Student not found with id: " + dto.getStudentId());
        }

        Visitor visitor = Visitor.builder()
                .visitorName(dto.getVisitorName())
                .phoneNumber(dto.getPhoneNumber())
                .studentId(dto.getStudentId())
                .entryTime(LocalDateTime.now())
                .exitTime(null)
                .build();

        visitor = visitorRepository.save(visitor);
        return convertToDTO(visitor);
    }

    public VisitorDTO updateVisitorExit(String visitorId) {
        Visitor visitor = visitorRepository.findById(visitorId)
                .orElseThrow(() -> new ResourceNotFoundException("Visitor record not found with id: " + visitorId));

        if (visitor.getExitTime() != null) {
            throw new BadRequestException("Visitor has already exited at: " + visitor.getExitTime());
        }

        visitor.setExitTime(LocalDateTime.now());
        visitor = visitorRepository.save(visitor);
        return convertToDTO(visitor);
    }

    public List<VisitorDTO> getVisitorHistory(String studentId) {
        List<Visitor> visitors;
        if (studentId != null && !studentId.isEmpty()) {
            if (!studentRepository.existsById(studentId)) {
                throw new ResourceNotFoundException("Student not found with id: " + studentId);
            }
            visitors = visitorRepository.findByStudentIdOrderByEntryTimeDesc(studentId);
        } else {
            visitors = visitorRepository.findAll();
        }

        return visitors.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public void deleteVisitor(String visitorId) {
        Visitor visitor = visitorRepository.findById(visitorId)
                .orElseThrow(() -> new ResourceNotFoundException("Visitor record not found with id: " + visitorId));
        visitorRepository.delete(visitor);
    }

    private VisitorDTO convertToDTO(Visitor visitor) {
        return VisitorDTO.builder()
                .visitorId(visitor.getVisitorId())
                .visitorName(visitor.getVisitorName())
                .phoneNumber(visitor.getPhoneNumber())
                .studentId(visitor.getStudentId())
                .entryTime(visitor.getEntryTime())
                .exitTime(visitor.getExitTime())
                .build();
    }
}
